
function openPopup(trailName, trailImage) {
    document.getElementById('popup-trail-name').textContent = trailName;
    document.getElementById('popup-trail-image').src = trailImage;
    document.getElementById('reservation-popup').style.display = 'flex';
}

function closePopup() {
    document.getElementById('reservation-popup').style.display = 'none';
}
