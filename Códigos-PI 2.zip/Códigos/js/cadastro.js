function validateCadastro() {
    // Pegando os valores dos campos
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const cpf = document.getElementById('cpf').value;
    const cep = document.getElementById('cep').value;
    const address = document.getElementById('address').value;
    const city = document.getElementById('city').value;
    const state = document.getElementById('state').value;

    // Validação simples para verificar se os campos estão preenchidos
    if (name === "" || email === "" || password === "" || cpf === "" || cep === "" || address === "" || city === "" || state === "") {
        alert("Por favor, preencha todos os campos.");
        return false; // Impede o envio do formulário
    }

    // Validação de e-mail simples
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        alert("Por favor, insira um e-mail válido.");
        return false; // Impede o envio do formulário
    }

    // Validação de CPF (apenas números, tamanho 11)
    const cpfPattern = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/;
    if (!cpfPattern.test(cpf)) {
        alert("Por favor, insira um CPF válido (formato: XXX.XXX.XXX-XX).");
        return false;
    }

    // Validação de CEP (apenas números, tamanho 8)
    const cepPattern = /^\d{5}-\d{3}$/;
    if (!cepPattern.test(cep)) {
        alert("Por favor, insira um CEP válido (formato: XXXXX-XXX).");
        return false;
    }

    // Se a validação passar, redireciona para a página de reserva
    window.location.href = "reserva.html";
    return false; // Impede o envio do formulário para não recarregar a página
}
