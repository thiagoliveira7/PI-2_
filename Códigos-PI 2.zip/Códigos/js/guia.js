document.addEventListener('DOMContentLoaded', () => {
    const visitantes = [
        {
            nome: "João Silva",
            email: "joao@exemplo.com",
            trilha: "Trilha do Paraíso",
            preco: "R$ 90,00",
            status: "confirmado"
        },
        {
            nome: "Maria Oliveira",
            email: "maria@exemplo.com",
            trilha: "Trilha da Cachoeira Dourada",
            preco: "R$ 75,00",
            status: "pendente"
        },
        {
            nome: "Carlos Souza",
            email: "carlos@exemplo.com",
            trilha: "Trilha do Vale das Orquídeas",
            preco: "R$ 80,00",
            status: "cancelado"
        }
    ];

    const tableBody = document.querySelector("#visitor-table tbody");

    // Função para adicionar cada visitante na tabela
    visitantes.forEach(visitor => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${visitor.nome}</td>
            <td>${visitor.email}</td>
            <td>${visitor.trilha}</td>
            <td>${visitor.preco}</td>
            <td class="status ${getStatusClass(visitor.status)}">${getStatusText(visitor.status)}</td>
        `;

        tableBody.appendChild(row);
    });

    // Função para determinar o estilo do status
    function getStatusClass(status) {
        switch (status) {
            case "confirmado":
                return "status-check";
            case "pendente":
                return "status-pending";
            case "cancelado":
                return "status-canceled";
            default:
                return "";
        }
    }

    // Função para exibir o texto do status
    function getStatusText(status) {
        switch (status) {
            case "confirmado":
                return "Confirmado";
            case "pendente":
                return "Pendente";
            case "cancelado":
                return "Cancelado";
            default:
                return "Desconhecido";
        }
    }
});
