function validateLogin() {
    // Pega os valores dos campos de email e senha
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Validação simples para verificar se os campos estão preenchidos
    if (email === "" || password === "") {
        alert("Por favor, preencha todos os campos.");
        return false; // Impede o envio do formulário
    }

    // Validação de e-mail simples
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        alert("Por favor, insira um e-mail válido.");
        return false; // Impede o envio do formulário
    }

    // Validação de senha mínima (simples)
    if (password.length < 6) {
        alert("A senha deve ter pelo menos 6 caracteres.");
        return false; // Impede o envio do formulário
    }

    // Se a validação passar, redireciona para a página de reserva
    window.location.href = "reserva.html";
    return false; // Impede o envio do formulário para não recarregar a página
}
