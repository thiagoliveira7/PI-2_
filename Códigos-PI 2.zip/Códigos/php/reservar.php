<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pix = $_POST['pix'];
    $trail_name = $_POST['trail_name'];

    // Inserir reserva no banco de dados
    $sql = "INSERT INTO reservas (trail_name, name, cpf, phone, email, pix) 
            VALUES (:trail_name, :name, :cpf, :phone, :email, :pix)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':trail_name', $trail_name);
    $stmt->bindParam(':name', $nome);
    $stmt->bindParam(':cpf', $cpf);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':pix', $pix);

    if ($stmt->execute()) {
        echo "Reserva confirmada com sucesso!";
    } else {
        echo "Erro ao realizar a reserva.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva de Trilha</title>
</head>
<body>
    <h1>Faça sua Reserva</h1>
    <form method="POST" action="">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required><br>

        <label for="cpf">CPF:</label>
        <input type="text" id="cpf" name="cpf" required><br>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="phone">Telefone:</label>
        <input type="text" id="phone" name="phone"><br>

        <label for="pix">Pix:</label>
        <input type="text" id="pix" name="pix"><br>

        <label for="trail_name">Trilha:</label>
        <select name="trail_name" id="trail_name" required>
            <?php
            // Obter todas as trilhas para exibir no dropdown
            $sql = "SELECT nome FROM trilhas";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $trilhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($trilhas as $trilha) {
                echo "<option value='{$trilha['nome']}'>{$trilha['nome']}</option>";
            }
            ?>
        </select><br>

        <button type="submit">Confirmar Reserva</button>
    </form>
</body>
</html>
