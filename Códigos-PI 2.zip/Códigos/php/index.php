<?php
include 'config.php';

// Consulta todas as trilhas
$sql = "SELECT * FROM trilhas";
$stmt = $conn->prepare($sql);
$stmt->execute();

$trilhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trilhas</title>
</head>
<body>
    <h1>Trilhas Disponíveis</h1>
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Preço</th>
                <th>Distância</th>
                <th>Benefícios</th>
                <th>Imagem</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($trilhas as $trilha): ?>
                <tr>
                    <td><?= $trilha['nome'] ?></td>
                    <td><?= 'R$ ' . number_format($trilha['preco'], 2, ',', '.') ?></td>
                    <td><?= $trilha['distancia'] . ' km' ?></td>
                    <td><?= $trilha['beneficios'] ?></td>
                    <td><img src="imagens/<?= $trilha['imagem'] ?>" alt="<?= $trilha['nome'] ?>" width="100"></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>