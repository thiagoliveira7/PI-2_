<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cpf = $_POST['cpf'];
    $senha = $_POST['senha'];

    // Buscar visitante pelo CPF
    $sql = "SELECT * FROM visitantes WHERE cpf = :cpf";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':cpf', $cpf);
    $stmt->execute();

    $visitante = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($visitante && password_verify($senha, $visitante['senha'])) {
        echo "Login bem-sucedido!";
        // Redirecionar ou mostrar dados do visitante
    } else {
        echo "CPF ou senha inválidos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login de Visitante</title>
</head>
<body>
    <h1>Login de Visitante</h1>
    <form method="POST" action="">
        <label for="cpf">CPF:</label>
        <input type="text" id="cpf" name="cpf" required><br>

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required><br>

        <button type="submit">Entrar</button>
    </form>
</body>
</html>
