<?php
// Configuração da conexão com o banco de dados
$host = 'localhost';          // Servidor MySQL
$dbname = 'trilhas_db';       // Nome do banco de dados
$username = 'usuario_banco';  // Nome de usuário do banco
$password = 'kyxa-2303935423';    // Senha do banco de dados

try {
    // Conexão com o banco de dados usando PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erro na conexão: " . $e->getMessage();
}
?>

