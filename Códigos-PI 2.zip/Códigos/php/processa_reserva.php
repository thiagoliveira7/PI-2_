<?php
// Configurações do banco de dados
$host = 'localhost';
$dbname = 'trilhas_db';
$username = 'root';
$password = 'kyxa-2303935423';

try {
    // Conexão com o banco de dados
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepara a inserção dos dados
    $stmt = $conn->prepare("INSERT INTO reservas (trail_name, name, cpf, phone, email, pix) VALUES (:trail_name, :name, :cpf, :phone, :email, :pix)");

    // Parâmetros para o SQL
    $stmt->bindParam(':trail_name', $_POST['trail_name']);
    $stmt->bindParam(':name', $_POST['name']);
    $stmt->bindParam(':cpf', $_POST['cpf']);
    $stmt->bindParam(':phone', $_POST['phone']);
    $stmt->bindParam(':email', $_POST['email']);
    $stmt->bindParam(':pix', $_POST['pix']);

    // Executa a inserção
    if ($stmt->execute()) {
        echo "Reserva realizada com sucesso!";
    } else {
        echo "Erro ao processar a reserva.";
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
