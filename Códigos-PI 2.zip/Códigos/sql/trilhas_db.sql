/*-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS trilhas_db;
USE trilhas_db;*/

-- Tabela de trilhas
CREATE TABLE trilhas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco DECIMAL(10, 2) NOT NULL,
    distancia DECIMAL(5, 2) NOT NULL,
    beneficios TEXT,
    imagem VARCHAR(255) -- URL da imagem da trilha
);

-- Tabela de reservas
CREATE TABLE reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trail_name VARCHAR(100) NOT NULL,
    name VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    phone VARCHAR(15),
    email VARCHAR(100) NOT NULL,
    pix VARCHAR(50),
    data_reserva TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('confirmado', 'pendente', 'cancelado') DEFAULT 'pendente',
    FOREIGN KEY (trail_name) REFERENCES trilhas(nome) ON DELETE CASCADE,
    FOREIGN KEY (cpf) REFERENCES visitantes(cpf) ON DELETE CASCADE
);

-- Tabela de visitantes
CREATE TABLE visitantes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    senha VARCHAR(255) NOT NULL, -- senha criptografada
    cpf VARCHAR(14) NOT NULL UNIQUE,
    cep VARCHAR(9),
    endereco VARCHAR(255),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de guias
CREATE TABLE guias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    trilha_id INT,
    especializacao VARCHAR(100),
    FOREIGN KEY (trilha_id) REFERENCES trilhas(id) ON DELETE SET NULL
);

-- Dados iniciais para a tabela de trilhas
INSERT INTO trilhas (nome, preco, distancia, beneficios, imagem)
VALUES
    ('Trilha das Árvores Gigantes', 65.00, 8.0, 'Passagens por árvores centenárias, área de sombra para descanso, guias especializados em botânica', 'trilha1.png'),
    ('Trilha do Paraíso', 90.00, 14.0, 'Vista panorâmica de toda a região, aventuras por áreas de difícil acesso, guia especializado em geografia e história local', 'trilha2.png'),
    ('Trilha da Cachoeira Dourada', 75.00, 6.0, 'Cachoeira com poço para banho, vistas deslumbrantes da cascata, passagens por bosques nativos, guia especializado em ecologia', 'trilha3.png'),
    ('Trilha do Vale das Orquídeas', 80.00, 7.0, 'Grande diversidade de orquídeas e flores, passagens por campos floridos, guia especializado em botânica', 'trilha4.png'),
    ('Trilha do Alto do Morro', 65.00, 5.0, 'Caminho com vista para a cidade, trilha de fácil acesso, perfeito para iniciantes, guia especializado em paisagens urbanas', 'trilha5.png'),
    ('Trilha da Mata Intocada', 95.00, 10.0, 'Trilha no coração da mata virgem, observação de fauna nativa rara, passagens por áreas de floresta densa, guia especializado em fauna e flora local', 'trilha6.png'),
    ('Trilha do Rio Sereno', 70.00, 6.5, 'Caminho ao longo do rio com áreas para descanso e banho, guias especializados em hidrologia e flora aquática', 'trilha7.png'),
    ('Trilha do Pico da Neblina', 100.00, 12.0, 'Caminho íngreme com clima de montanha, ideal para escaladores e aventureiros, guias experientes em trilhas de altitude', 'trilha8.png'),
    ('Trilha das Grutas Secretas', 85.00, 9.0, 'Exploração de grutas e cavernas, áreas iluminadas por formações de cristal, guia especializado em geologia', 'trilha9.png'),
    ('Trilha dos Mirantes', 60.00, 4.5, 'Várias paradas com mirantes panorâmicos, ideal para fotografia e observação de paisagens, guia especializado em paisagismo', 'trilha10.png'),
    ('Trilha da Ponte Suspensa', 75.00, 6.0, 'Trilha com passagem por ponte suspensa, vistas incríveis do vale, guia especializado em estruturas e engenharia', 'trilha11.png'),
    ('Trilha dos Animais Selvagens', 85.00, 11.0, 'Observação de fauna silvestre com alta biodiversidade, guias especializados em biologia e comportamento animal', 'trilha12.png'),
    ('Trilha do Lago Escondido', 70.00, 8.5, 'Caminho que leva a um lago escondido entre montanhas, ideal para piqueniques e descanso, guia especializado em ecoturismo', 'trilha13.png'),
    ('Trilha da Floresta Encantada', 90.00, 9.5, 'Trilha em floresta densa com árvores exóticas, áreas de camping, guia especializado em flora local', 'trilha14.png'),
    ('Trilha da Pedra Grande', 80.00, 7.0, 'Caminho com final na Pedra Grande, local icônico para ver o pôr do sol, guia especializado em topografia e história local', 'trilha15.png');
